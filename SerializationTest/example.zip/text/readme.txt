Information about this package.
========================
